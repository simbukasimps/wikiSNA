from flask import Flask, request, jsonify, render_template, Response
import networkx as nx
import wikipedia
import json
import re
import community as community_louvain
from sklearn.metrics import silhouette_score
from collections import defaultdict
import numpy as np
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import os
import pickle

app = Flask(__name__, static_folder='static', template_folder='templates')

# Initialize the graph or load from file if it exists
GRAPH_FILE = 'wikipedia_graph.pickle'
# if os.path.exists(GRAPH_FILE):
#     with open(GRAPH_FILE, 'rb') as f:
#         G = pickle.load(f)
# else:
#     G = nx.DiGraph()

G = nx.DiGraph()

# Cache for Wikipedia pages
page_cache = {}

@app.route('/')
def index():
    """Render the main application page."""
    return render_template('index.html')

# @app.route('/api/page/<title>')
# def get_page(title):
#     """Fetch a Wikipedia page, add only the title as a node, and check for edges with existing nodes."""
#     title = title.replace('_', ' ')
    
#     # Check cache first
#     if title in page_cache:
#         return jsonify(page_cache[title])

#     try:
#         # Get page content from Wikipedia API
#         page = wikipedia.page(title, auto_suggest=False)

#         # Add only the requested page as a node
#         if title not in G:
#             G.add_node(title, id=title, pageid=page.pageid)

#         # Check for connections with existing nodes
#         for existing_node in list(G.nodes):
#             if existing_node == title:
#                 continue
            
#             try:
#                 # Get links of the existing node
#                 existing_page = wikipedia.page(existing_node, auto_suggest=False)
#                 existing_links = set(existing_page.links)

#                 # If the title appears in the existing page's links, create an edge
#                 if title in existing_links:
#                     G.add_edge(existing_node, title)

#                 # If the existing node appears in the new page's links, create an edge
#                 if existing_node in page.links:
#                     G.add_edge(title, existing_node)

#             except:
#                 continue  # Skip if there's an issue fetching the page
        
#         # Save the graph
#         # with open(GRAPH_FILE, 'wb') as f:
#         #     pickle.dump(G, f)

#         # Prepare response data
#         result = {
#             'title': title,
#             'content': page.html(),
#             'pageid': page.pageid
#         }

#         # Cache the result
#         page_cache[title] = result

#         return jsonify(result)

#     except Exception as e:
#         return jsonify({'error': str(e)}), 404

@app.route('/api/page/<title>')
def get_page(title):
    """Fetch a Wikipedia page and extract its links."""
    title = title.replace('_', ' ')
    
    # Check cache first
    if title in page_cache:
        return jsonify(page_cache[title])
    
    try:
        # Get page content from Wikipedia API
        page = wikipedia.page(title, auto_suggest=False)
        
        # Extract links
        links = []
        for link in page.links:
            if link and not re.match(r'(File:|Image:|Category:|Help:|Wikipedia:|Portal:|Talk:|Template:)', link):
                links.append(link)
        
        # Update the graph
        if title not in G:
            G.add_node(title, id=title, pageid=page.pageid)
        
        for link in links:
            if link not in G:
                try:
                    link_page = wikipedia.page(link, auto_suggest=False)
                    G.add_node(link, id=link, pageid=link_page.pageid)
                except:
                    continue
            
            G.add_edge(title, link)
        
        # Save graph
       # with open(GRAPH_FILE, 'wb') as f:
       #     pickle.dump(G, f)
        
        # Prepare response data
        result = {
            'title': title,
            'content': page.html(),
            'pageid': page.pageid,
            'links': links
        }
        
        # Cache the result
        page_cache[title] = result
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 404

@app.route('/api/graph')
def get_graph():
    """Return the current graph structure."""
    nodes = [{'id': node, 'pageid': G.nodes[node].get('pageid')} for node in G.nodes()]
    links = [{'source': s, 'target': t} for s, t in G.edges()]
    
    return jsonify({
        'nodes': nodes,
        'links': links
    })

@app.route('/api/centrality')
def get_centrality():
    """Compute and return centrality metrics for nodes in the graph."""
    if len(G) == 0:
        return jsonify({'error': 'Graph is empty'}), 400
    
    # Calculate centrality metrics
    pagerank = nx.pagerank(G)
    in_degree = dict(G.in_degree())
    out_degree = dict(G.out_degree())
    
    # Calculate betweenness centrality if graph isn't too large
    if len(G) <= 100:  # Limit for performance reasons
        betweenness = nx.betweenness_centrality(G)
    else:
        # Use approximate betweenness for larger graphs
        betweenness = nx.betweenness_centrality(G, k=min(len(G), 10))
    
    # Combine results
    results = []
    for node in G.nodes():
        results.append({
            'node': node,
            'pagerank': pagerank.get(node, 0),
            'in_degree': in_degree.get(node, 0),
            'out_degree': out_degree.get(node, 0),
            'betweenness': betweenness.get(node, 0)
        })
    
    # Sort by PageRank (most important first)
    results.sort(key=lambda x: x['pagerank'], reverse=True)
    
    return jsonify(results)

@app.route('/api/shortest_path')
def find_shortest_path():
    """Find shortest path between two nodes."""
    source = request.args.get('source')
    target = request.args.get('target')
    
    if not source or not target:
        return jsonify({'error': 'Source and target parameters are required'}), 400
    
    if source not in G or target not in G:
        return jsonify({'error': 'Source or target node not found in graph'}), 404
    
    try:
        path = nx.shortest_path(G, source=source, target=target)
        path_data = []
        
        # Get edge information for the path
        for i in range(len(path) - 1):
            path_data.append({
                'source': path[i],
                'target': path[i + 1]
            })
            
        return jsonify({
            'path': path,
            'path_data': path_data,
            'length': len(path) - 1
        })
    except nx.NetworkXNoPath:
        return jsonify({'error': 'No path exists between these nodes'}), 404

@app.route('/api/communities')
def detect_communities():
    """Detect communities in the graph using Louvain method."""
    if len(G) == 0:
        return jsonify({'error': 'Graph is empty'}), 400
    
    # Convert directed graph to undirected for community detection
    G_undirected = G.to_undirected()
    
    # Apply Louvain community detection
    partition = community_louvain.best_partition(G_undirected)
    
    # Group nodes by community
    communities = defaultdict(list)
    for node, community_id in partition.items():
        communities[community_id].append(node)
    
    # Convert to list and sort by community size
    community_list = [{'id': cid, 'nodes': nodes} for cid, nodes in communities.items()]
    community_list.sort(key=lambda x: len(x['nodes']), reverse=True)
    
    # Add community info to nodes
    node_communities = []
    for node in G.nodes():
        if node in partition:
            node_communities.append({
                'node': node,
                'community': partition[node]
            })
    
    return jsonify({
        'communities': community_list,
        'node_communities': node_communities
    })

@app.route('/api/anomalies')
def detect_anomalies():
    """Detect anomalous nodes in the graph."""
    if len(G) == 0:
        return jsonify({'error': 'Graph is empty'}), 400
    
    # Calculate statistics
    in_degrees = dict(G.in_degree())
    out_degrees = dict(G.out_degree())
    pagerank = nx.pagerank(G)
    
    # Calculate mean and std for in/out degrees
    in_degree_values = list(in_degrees.values())
    out_degree_values = list(out_degrees.values())
    
    in_mean = np.mean(in_degree_values)
    in_std = np.std(in_degree_values)
    out_mean = np.mean(out_degree_values)
    out_std = np.std(out_degree_values)
    
    # Find anomalies (nodes with degrees more than 2 std from mean)
    anomalies = []
    
    for node in G.nodes():
        is_anomaly = False
        anomaly_type = []
        
        # Check in-degree
        if abs(in_degrees[node] - in_mean) > 2 * in_std:
            is_anomaly = True
            if in_degrees[node] > in_mean:
                anomaly_type.append('high_in_degree')
            else:
                anomaly_type.append('low_in_degree')
        
        # Check out-degree
        if abs(out_degrees[node] - out_mean) > 2 * out_std:
            is_anomaly = True
            if out_degrees[node] > out_mean:
                anomaly_type.append('high_out_degree')
            else:
                anomaly_type.append('low_out_degree')
        
        # Orphan pages (no incoming links)
        if in_degrees[node] == 0 and G.out_degree(node) > 0:
            is_anomaly = True
            anomaly_type.append('orphan')
        
        # Dead-end pages (no outgoing links)
        if out_degrees[node] == 0 and G.in_degree(node) > 0:
            is_anomaly = True
            anomaly_type.append('dead_end')
        
        if is_anomaly:
            anomalies.append({
                'node': node,
                'type': anomaly_type,
                'in_degree': in_degrees[node],
                'out_degree': out_degrees[node],
                'pagerank': pagerank[node]
            })
    
    return jsonify(anomalies)

@app.route('/api/temporal/<title>')
def temporal_analysis(title):
    """Analyze historical versions of a Wikipedia page (simplified approach)."""
    title = title.replace('_', ' ')
    
    try:
        # Get current revision IDs (simplified - in real app would fetch multiple revisions)
        revisions_url = f"https://en.wikipedia.org/w/api.php?action=query&prop=revisions&titles={title}&rvlimit=5&rvprop=ids|timestamp&format=json"
        response = requests.get(revisions_url)
        data = response.json()
        
        page_id = list(data['query']['pages'].keys())[0]
        if page_id == "-1":
            return jsonify({'error': 'Page not found'}), 404
            
        revisions = data['query']['pages'][page_id].get('revisions', [])
        
        # For demonstration, just return the revision data
        # In a real implementation, we would fetch the content of each revision
        # and analyze how links have changed over time
        return jsonify({
            'title': title,
            'revisions': revisions,
            'note': 'For full implementation, each revision would be analyzed for link changes'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict_links')
def predict_links():
    """Predict potential missing links in the graph (simple heuristic approach)."""
    if len(G) < 5:  # Need a reasonable amount of data
        return jsonify({'error': 'Not enough data in graph for prediction'}), 400
    
    # Use a simple heuristic: nodes that share many common neighbors
    # are likely to be connected
    
    predictions = []
    
    # For each pair of unconnected nodes
    for node1 in G.nodes():
        for node2 in G.nodes():
            # Skip if already connected or same node
            if node1 == node2 or G.has_edge(node1, node2):
                continue
                
            # Get common neighbors
            node1_neighbors = set(G.successors(node1))
            node2_neighbors = set(G.predecessors(node2))
            common_neighbors = node1_neighbors.intersection(node2_neighbors)
            
            if len(common_neighbors) >= 2:  # Threshold for prediction
                predictions.append({
                    'source': node1,
                    'target': node2,
                    'common_neighbors': len(common_neighbors),
                    'common_neighbor_list': list(common_neighbors)
                })
    
    # Sort by number of common neighbors (most likely first)
    predictions.sort(key=lambda x: x['common_neighbors'], reverse=True)
    
    # Return top 10 predictions
    return jsonify(predictions[:10])

@app.route('/api/clear_node/<title>')
def clear_node(title):
    """Remove a node from the graph."""
    title = title.replace('_', ' ')
    
    if title in G:
        G.remove_node(title)
        
        # Save the updated graph
        # with open(GRAPH_FILE, 'wb') as f:
        #     pickle.dump(G, f)
            
        return jsonify({'status': 'success', 'message': f'Node {title} removed'})
    else:
        return jsonify({'error': 'Node not found'}), 404

@app.route('/wikipedia_html/<path:title>')
def wikipedia_html(title):
    """Fetch and return processed Wikipedia HTML."""
    title = title.replace('_', ' ')
    
    try:
        # Get Wikipedia page content with HTML
        page = wikipedia.page(title, auto_suggest=False)
        html_content = page.html()
        
        # Create a response with proper content type
        return Response(html_content, mimetype='text/html')
    except Exception as e:
        return f"<div class='error'>Error loading page: {str(e)}</div>", 404

@app.route('/api/search')
def search_wikipedia():
    """Search Wikipedia for pages matching a query."""
    query = request.args.get('q', '')
    if not query:
        return jsonify({'results': []})
    
    try:
        # Search Wikipedia
        search_results = wikipedia.search(query, results=10)
        return jsonify({'results': search_results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
