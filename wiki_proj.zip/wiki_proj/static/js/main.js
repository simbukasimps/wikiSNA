// Global variables
let currentPage = null;
let simulation = null;
let dataLinks = {};
let dataNodes = {};
let backStack = [];
let forwardStack = [];
let selectedSearchRes = null;
const height = 600;
const width = 600;

// DOM elements
const searchButton = d3.select("#searchViewButton");
const backButton = d3.select("#backButton");
const forwardButton = d3.select("#forwardButton");
const deleteButton = d3.select("#deleteButton");
const searchDiv = d3.select("#searchDiv");
const wikiContent = d3.select("#wikiContent");
const inputTitel = d3.select("#inputTitel");
const suggestions = d3.select("#suggestions").node();

// Initialize SVG
const svg = d3.select("#svgcontainer").append("svg")
    .style("flex-grow", "1")
    .attr("viewBox", [0, 0, width, height]);

svg.call(d3.zoom()
    .on("zoom", function({transform}) {
        container.attr("transform", transform);
    })
);

let container = svg.append("g");

let link = container.append("g")
    .attr("stroke", "#333")
    .attr("stroke-opacity", 0.3)
    .attr("stroke-width", 5)
    .attr("fill", "transparent")
    .attr("stroke-linecap", "round")
    .selectAll("path");

let node = container.append("g")
    .style("text-anchor", "middle")
    .style("dominant-baseline", "central")
    .classed("noselect", true)
    .selectAll("text");

// Setup drag functionality
function drag(simulation) {
    function dragstarted(event) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
    }
    
    function dragged(event) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
    }
    
    function dragended(event) {
        if (!event.active) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
    }
    
    return d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);
}

// Search functionality
function setupSearch() {
    let isSearch = true;
    
    // Toggle between search and article view
    searchButton.on("click", function() {
        if (isSearch) {
            searchDiv.style("display", "none");
            wikiContent.style("display", "block");
            d3.select(this).classed("search", false).classed("view", true);
        } else {
            searchDiv.style("display", "block");
            wikiContent.style("display", "none");
            d3.select(this).classed("view", false).classed("search", true);
        }
        isSearch = !isSearch;
    });
    
    // Setup search input with autocomplete
    inputTitel.on("input", function() {
        const query = this.value.trim();
        if (query.length < 2) {
            d3.select("#suggestions").html("");
            return;
        }
        
        fetch(`/api/search?q=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                const suggestionsList = data.results.map((title, index) => 
                    `<div class="suggestion" data-index="${index}">${title}</div>`
                ).join("");
                
                d3.select("#suggestions").html(suggestionsList);
                
                d3.selectAll(".suggestion").on("click", function() {
                    const title = this.textContent;
                    inputTitel.property("value", title);
                    d3.select("#suggestions").html("");
                    loadPage(title);
                });
                
                d3.selectAll(".suggestion").on("mouseover", function() {
                    d3.selectAll(".suggestion").classed("selected", false);
                    d3.select(this).classed("selected", true);
                    selectedSearchRes = parseInt(d3.select(this).attr("data-index"));
                });
            })
            .catch(error => console.error("Error searching Wikipedia:", error));
    });
    
    // Handle keyboard navigation for suggestions
    inputTitel.on("keydown", function(event) {
        const suggestions = d3.selectAll(".suggestion");
        const numSuggestions = suggestions.size();
        
        if (numSuggestions === 0) return;
        
        if (event.key === "ArrowDown") {
            event.preventDefault();
            selectedSearchRes = (selectedSearchRes === null || selectedSearchRes >= numSuggestions - 1) ? 0 : selectedSearchRes + 1;
            suggestions.classed("selected", false);
            suggestions.filter((d, i) => i === selectedSearchRes).classed("selected", true);
        } else if (event.key === "ArrowUp") {
            event.preventDefault();
            selectedSearchRes = (selectedSearchRes === null || selectedSearchRes <= 0) ? numSuggestions - 1 : selectedSearchRes - 1;
            suggestions.classed("selected", false);
            suggestions.filter((d, i) => i === selectedSearchRes).classed("selected", true);
        } else if (event.key === "Enter") {
            event.preventDefault();
            if (selectedSearchRes !== null) {
                const selectedTitle = suggestions.filter((d, i) => i === selectedSearchRes).text();
                inputTitel.property("value", selectedTitle);
                d3.select("#suggestions").html("");
                loadPage(selectedTitle);
            } else if (inputTitel.property("value").trim() !== "") {
                loadPage(inputTitel.property("value"));
            }
        }
    });
    
    // Random article button
    d3.select("#randomArticle").on("click", function() {
        // Wikipedia has a special API for random articles
        fetch("https://en.wikipedia.org/api/rest_v1/page/random/title")
            .then(response => response.json())
            .then(data => {
                const randomTitle = data.items[0].title;
                loadPage(randomTitle);
            })
            .catch(error => {
                console.error("Error fetching random article:", error);
                // Fallback to a list of popular articles
                const popularArticles = [
                    "Machine Learning", "Artificial Intelligence", "Python (programming language)",
                    "Data Science", "Network Theory", "Graph Theory"
                ];
                const randomTitle = popularArticles[Math.floor(Math.random() * popularArticles.length)];
                loadPage(randomTitle);
            });
    });
}

// Load Wikipedia page and add to graph
function loadPage(title) {
    // Don't reload if already on this page
    if (currentPage === title) return;
    
    // Update UI
    searchDiv.style("display", "none");
    wikiContent.style("display", "block");
    searchButton.classed("search", false).classed("view", true);
    
    // Show loading indicator
    wikiContent.html("<div class='loading'>Loading...</div>");
    
    // Update navigation stack
    if (currentPage) {
        backStack.push(currentPage);
        forwardStack = [];
        backButton.property("disabled", false);
        forwardButton.property("disabled", true);
    }
    currentPage = title;
    
    // Update the open in Wikipedia button
    const wikiUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`;
    d3.select("#openInWikipediaA").attr("href", wikiUrl);
    deleteButton.property("disabled", false);
    
    // Fetch page from our API
    fetch(`/api/page/${encodeURIComponent(title)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error("Page not found");
            }
            return response.json();
        })
        .then(data => {
            // Load Wikipedia content
            wikiContent.html("");
            
            // Create iframe to safely render Wikipedia HTML
            const iframe = document.createElement("iframe");
            iframe.style.width = "100%";
            iframe.style.height = "100%";
            iframe.style.border = "none";
            wikiContent.node().appendChild(iframe);
            
            // Load content into iframe
            fetch(`/wikipedia_html/${encodeURIComponent(title)}`)
                .then(response => response.text())
                .then(htmlContent => {
                    const doc = iframe.contentDocument || iframe.contentWindow.document;
                    doc.open();
                    doc.write(htmlContent);
                    doc.close();
                    
                    // Intercept link clicks inside iframe
                    doc.addEventListener('click', function(e) {
                        const target = e.target.closest('a');
                        if (target && target.href && !target.href.startsWith('javascript:')) {
                            e.preventDefault();
                            
                            // Extract the page title from the link
                            const href = target.getAttribute('href');
                            if (href && href.startsWith('/wiki/')) {
                                const linkTitle = decodeURIComponent(href.substring(6)).replace(/_/g, ' ');
                                // Ignore special pages
                                if (!linkTitle.includes(':')) {
                                    loadPage(linkTitle);
                                }
                            }
                        }
                    });
                })
                .catch(error => {
                    wikiContent.html(`<div class="error">Error loading Wikipedia content: ${error.message}</div>`);
                });
            
            // Update graph with new data
            updateGraph(data);
        })
        .catch(error => {
            wikiContent.html(`<div class="error">Error: ${error.message}</div>`);
        });
}

// Update graph visualization with new data
function updateGraph(pageData) {
    // Fetch the current graph to merge with new data
    fetch('/api/graph')
        .then(response => response.json())
        .then(graphData => {
            // Remove any loading indicators
            d3.select("#svgcontainer .loading").remove();
            
            // Update node and link data
            dataNodes = {};
            graphData.nodes.forEach(node => {
                dataNodes[node.id] = node;
            });
            
            dataLinks = {};
            graphData.links.forEach(link => {
                const linkId = `${link.source}->${link.target}`;
                dataLinks[linkId] = link;
            });
            
            // Update force simulation
            updateSimulation();
            
            // Update path analysis selectors
            updatePathSelectors();
        })
        .catch(error => {
            console.error("Error fetching graph data:", error);
        });
}

// Update force simulation with current nodes and links
function updateSimulation() {
    const nodes = Object.values(dataNodes);
    const links = Object.values(dataLinks);
    
    // Create or update force simulation
    if (!simulation) {
        simulation = d3.forceSimulation(nodes)
            .force("link", d3.forceLink(links).id(d => d.id).distance(100))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .on("tick", ticked);
    } else {
        simulation.nodes(nodes);
        simulation.force("link").links(links);
        simulation.alpha(0.3).restart();
    }
    
    // Update links
    link = link.data(links, d => `${d.source.id}->${d.target.id}`);
    link.exit().remove();
    
    const linkEnter = link.enter().append("path")
        .attr("class", "link")
        .attr("marker-end", "url(#arrowhead)");
    
    link = linkEnter.merge(link);
    
    // Update nodes
    node = node.data(nodes, d => d.id);
    node.exit().remove();
    
    const nodeEnter = node.enter().append("text")
        .attr("class", "node")
        .text(d => {
            // Truncate node labels if they're too long
            const name = d.id;
            return name.length > 20 ? name.substring(0, 18) + "..." : name;
        })
        .attr("font-size", d => {
            // Size nodes based on in-degree (number of incoming links)
            const inDegree = links.filter(l => l.target.id === d.id).length;
            return Math.max(12, Math.min(20, 12 + inDegree * 0.5)) + "px";
        })
        .call(drag(simulation))
        .on("click", function(event, d) {
            event.stopPropagation();
            loadPage(d.id);
        });
    
    node = nodeEnter.merge(node);
    
    // Highlight current page
    node.classed("current", d => d.id === currentPage);
    
    // Create arrowhead marker if it doesn't exist
    if (!svg.select("defs").node()) {
        svg.append("defs").append("marker")
            .attr("id", "arrowhead")
            .attr("viewBox", "0 -5 10 10")
            .attr("refX", 15)
            .attr("refY", 0)
            .attr("orient", "auto")
            .attr("markerWidth", 6)
            .attr("markerHeight", 6)
            .append("path")
            .attr("d", "M0,-5L10,0L0,5")
            .attr("fill", "#999");
    }
}

// Tick function for force simulation
function ticked() {
    link.attr("d", d => {
        const dx = d.target.x - d.source.x;
        const dy = d.target.y - d.source.y;
        const dr = Math.sqrt(dx * dx + dy * dy);
        
        // Use quadratic bezier for curve
        const mx = d.source.x + dx / 2;
        const my = d.source.y + dy / 2;
        const qx = mx - dy * 0.2;
        const qy = my + dx * 0.2;
        
        return `M${d.source.x},${d.source.y} Q${qx},${qy} ${d.target.x},${d.target.y}`;
    });
    
    node.attr("x", d => d.x)
        .attr("y", d => d.y);
}

// Setup navigation buttons
function setupNavigation() {
    // Back button
    backButton.on("click", function() {
        if (backStack.length > 0) {
            const previousPage = backStack.pop();
            forwardStack.push(currentPage);
            forwardButton.property("disabled", false);
            
            if (backStack.length === 0) {
                backButton.property("disabled", true);
            }
            
            loadPage(previousPage);
        }
    });
    
    // Forward button
    forwardButton.on("click", function() {
        if (forwardStack.length > 0) {
            const nextPage = forwardStack.pop();
            backStack.push(currentPage);
            backButton.property("disabled", false);
            
            if (forwardStack.length === 0) {
                forwardButton.property("disabled", true);
            }
            
            loadPage(nextPage);
        }
    });
    
    // Delete button (remove current node)
    deleteButton.on("click", function() {
        if (currentPage) {
            // Confirm deletion
            if (confirm(`Remove "${currentPage}" from the graph?`)) {
                fetch(`/api/clear_node/${encodeURIComponent(currentPage)}`)
                    .then(response => response.json())
                    .then(data => {
                        // Go back if possible, otherwise go to search
                        if (backStack.length > 0) {
                            const previousPage = backStack.pop();
                            loadPage(previousPage);
                        } else {
                            // Return to search
                            currentPage = null;
                            searchDiv.style("display", "block");
                            wikiContent.style("display", "none");
                            searchButton.classed("view", false).classed("search", true);
                            deleteButton.property("disabled", true);
                        }
                        
                        // Update graph visualization
                        fetch('/api/graph')
                            .then(response => response.json())
                            .then(graphData => updateGraph(graphData))
                            .catch(error => console.error("Error updating graph:", error));
                    })
                    .catch(error => console.error("Error removing node:", error));
            }
        }
    });
    
    // Share button
    d3.select("#shareButton").on("click", function() {
        const graphUrl = window.location.origin + "?graph=current";
        alert("Share this URL to share your current graph:\n\n" + graphUrl);
    });
    
    // About button
    d3.select("#aboutButton").on("click", function() {
        alert("Wikipedia Graph Explorer\n\nThis tool allows you to explore Wikipedia by visualizing the connections between articles as a directed graph. Click on nodes to navigate between articles, and use the analysis tools to discover patterns in the network structure.");
    });
    
    // Help button
    d3.select("#helpButton").on("click", function() {
        alert("How to use:\n\n1. Search for a Wikipedia article or click 'Random Article'\n2. Browse articles by clicking on links in the text or nodes in the graph\n3. Use the analysis tabs to explore graph properties:\n   - Centrality: Find the most important articles\n   - Path Analysis: Find shortest paths between articles\n   - Communities: Detect clusters of related articles\n   - Anomalies: Find unusual connection patterns\n   - Predictions: Discover potential missing links\n\n4. Use the navigation buttons to go back/forward or remove articles from the graph");
    });
    
    // GitHub button
    d3.select("#githubButton").on("click", function() {
        window.open("https://github.com/yourusername/wikipedia-graph-explorer", "_blank");
    });
}

// Setup resize functionality for panels
function setupResizing() {
    const dragBar = d3.select("#dragBar");
    const leftPanel = d3.select("#left-panel");
    const rightPanel = d3.select("#right-panel");
    const container = d3.select("#main-container");
    
    let isDragging = false;
    let startX;
    let startWidth;
    
    dragBar.on("mousedown", function(event) {
        isDragging = true;
        startX = event.clientX;
        startWidth = leftPanel.node().offsetWidth;
        
        // Add event listeners
        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
        
        // Prevent text selection during drag
        event.preventDefault();
    });
    
    function onMouseMove(event) {
        if (!isDragging) return;
        
        const containerWidth = container.node().offsetWidth;
        const minWidth = 200;
        const maxWidth = containerWidth - 200;
        
        let newWidth = startWidth + (event.clientX - startX);
        newWidth = Math.max(minWidth, Math.min(maxWidth, newWidth));
        
        leftPanel.style("flex-basis", newWidth + "px");
        
        // Update simulation if it exists
        if (simulation) {
            simulation.alpha(0.3).restart();
        }
    }
    
    function onMouseUp() {
        isDragging = false;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
    }
}

// Setup tab functionality
function setupTabs() {
    const tabButtons = d3.selectAll(".tab-button");
    const tabContents = d3.selectAll(".tab-content");
    
    tabButtons.on("click", function() {
        const tabId = d3.select(this).attr("data-tab");
        
        // Hide all tabs and deactivate buttons
        tabContents.classed("active", false);
        tabButtons.classed("active", false);
        
        // Show selected tab and activate button
        d3.select("#" + tabId).classed("active", true);
        d3.select(this).classed("active", true);
    });
}

// Setup centrality analysis
function setupCentralityAnalysis() {
    d3.select("#refreshCentrality").on("click", function() {
        const resultsDiv = d3.select("#centralityResults");
        resultsDiv.html("<p>Loading centrality analysis...</p>");
        
        fetch("/api/centrality")
            .then(response => response.json())
            .then(data => {
                // Create table for centrality metrics
                let html = `
                    <table>
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Page</th>
                                <th>PageRank</th>
                                <th>In-Degree</th>
                                <th>Out-Degree</th>
                                <th>Betweenness</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                // Add top 15 pages by PageRank
                data.slice(0, 15).forEach((item, index) => {
                    html += `
                        <tr>
                            <td>${index + 1}</td>
                            <td><a href="#" class="page-link">${item.node}</a></td>
                            <td>${item.pagerank.toFixed(4)}</td>
                            <td>${item.in_degree}</td>
                            <td>${item.out_degree}</td>
                            <td>${item.betweenness.toFixed(4)}</td>
                        </tr>
                    `;
                });
                
                html += "</tbody></table>";
                resultsDiv.html(html);
                
                // Add click handlers to page links
                resultsDiv.selectAll(".page-link").on("click", function(event) {
                    event.preventDefault();
                    const title = this.textContent;
                    loadPage(title);
                });
            })
            .catch(error => {
                resultsDiv.html(`<p class="error">Error: ${error.message}</p>`);
            });
    });
}

// Update path analysis selectors
function updatePathSelectors() {
    const sourceSelect = d3.select("#pathSource");
    const targetSelect = d3.select("#pathTarget");
    
    // Get sorted node list
    const nodes = Object.values(dataNodes).map(d => d.id).sort();
    
    // Update source select
    const sourceOptions = sourceSelect.selectAll("option")
        .data(nodes);
        
    sourceOptions.exit().remove();
    
    sourceOptions.enter()
        .append("option")
        .merge(sourceOptions)
        .attr("value", d => d)
        .text(d => d);
        
    // Update target select
    const targetOptions = targetSelect.selectAll("option")
        .data(nodes);
        
    targetOptions.exit().remove();
    
    targetOptions.enter()
        .append("option")
        .merge(targetOptions)
        .attr("value", d => d)
        .text(d => d);
        
    // Set current page as default source if it exists
    if (currentPage && nodes.includes(currentPage)) {
        sourceSelect.property("value", currentPage);
    }
}

// Setup path analysis
function setupPathAnalysis() {
    d3.select("#findPathButton").on("click", function() {
        const source = d3.select("#pathSource").property("value");
        const target = d3.select("#pathTarget").property("value");
        
        if (!source || !target || source === target) {
            d3.select("#pathResults").html("<p class='error'>Please select different source and target nodes.</p>");
            return;
        }
        
        d3.select("#pathResults").html("<p>Finding shortest path...</p>");
        
        fetch(`/api/shortest_path?source=${encodeURIComponent(source)}&target=${encodeURIComponent(target)}`)
            .then(response => {
                if (!response.ok) {
                    return response.json().then(err => { throw new Error(err.error) });
                }
                return response.json();
            })
            .then(data => {
                // Create path display
                let html = `
                    <p>Shortest path from <strong>${source}</strong> to <strong>${target}</strong> (${data.length} clicks):</p>
                    <div class="path-visualization">
                `;
                
                data.path.forEach((node, index) => {
                    if (index > 0) {
                        html += ` → `;
                    }
                    html += `<a href="#" class="path-node">${node}</a>`;
                });
                
                html += `</div>`;
                
                d3.select("#pathResults").html(html);
                
                // Add click handlers to path nodes
                d3.selectAll(".path-node").on("click", function(event) {
                    event.preventDefault();
                    const nodeName = this.textContent;
                    loadPage(nodeName);
                });
                
                // Highlight path in the graph
                link.classed("path-highlight", false);
                node.classed("node-highlight", false);
                
                data.path_data.forEach(edge => {
                    link.filter(d => 
                        (d.source.id === edge.source || d.source === edge.source) && 
                        (d.target.id === edge.target || d.target === edge.target)
                    ).classed("path-highlight", true);
                });
                
                data.path.forEach(nodeName => {
                    node.filter(d => d.id === nodeName).classed("node-highlight", true);
                });
            })
            .catch(error => {
                d3.select("#pathResults").html(`<p class="error">Error: ${error.message}</p>`);
            });
    });
}

// Setup community detection
function setupCommunityDetection() {
    d3.select("#refreshCommunities").on("click", function() {
        const resultsDiv = d3.select("#communityResults");
        resultsDiv.html("<p>Detecting communities...</p>");
        
        fetch("/api/communities")
            .then(response => response.json())
            .then(data => {
                // Display community results
                let html = `<p>Detected ${data.communities.length} communities:</p>`;
                
                // Create a table of communities
                html += `
                    <table>
                        <thead>
                            <tr>
                                <th>Community ID</th>
                                <th>Size</th>
                                <th>Top Members</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                data.communities.forEach(community => {
                    // Get up to 5 members to display
                    const topMembers = community.nodes.slice(0, 5).join(", ");
                    const moreMembers = community.nodes.length > 5 ? ` and ${community.nodes.length - 5} more` : "";
                    
                    html += `
                        <tr>
                            <td class="community-${community.id % 10}">${community.id}</td>
                            <td>${community.nodes.length}</td>
                            <td>${topMembers}${moreMembers}</td>
                        </tr>
                    `;
                });
                
                html += "</tbody></table>";
                
                resultsDiv.html(html);
                
                // Color nodes in the graph by community
                const nodeCommunities = {};
                data.node_communities.forEach(item => {
                    nodeCommunities[item.node] = item.community;
                });
                
                // Apply colors to nodes in the graph
                node.style("fill", d => {
                    const communityId = nodeCommunities[d.id];
                    if (communityId !== undefined) {
                        return d3.select(`.community-${communityId % 10}`).style("color");
                    }
                    return null;
                });
            })
            .catch(error => {
                resultsDiv.html(`<p class="error">Error: ${error.message}</p>`);
            });
    });
}

// Setup anomaly detection
function setupAnomalyDetection() {
    d3.select("#refreshAnomalies").on("click", function() {
        const resultsDiv = d3.select("#anomalyResults");
        resultsDiv.html("<p>Detecting anomalies...</p>");
        
        fetch("/api/anomalies")
            .then(response => response.json())
            .then(data => {
                if (data.length === 0) {
                    resultsDiv.html("<p>No anomalies detected in the current graph.</p>");
                    return;
                }
                
                // Create table for anomalies
                let html = `
                    <table>
                        <thead>
                            <tr>
                                <th>Page</th>
                                <th>Anomaly Type</th>
                                <th>In-Degree</th>
                                <th>Out-Degree</th>
                                <th>PageRank</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                data.forEach(item => {
                    const anomalyTypes = item.type.map(type => {
                        switch(type) {
                            case 'high_in_degree': return 'Many inbound links';
                            case 'low_in_degree': return 'Few inbound links';
                            case 'high_out_degree': return 'Many outbound links';
                            case 'low_out_degree': return 'Few outbound links';
                            case 'orphan': return 'Orphan page';
                            case 'dead_end': return 'Dead-end page';
                            default: return type;
                        }
                    }).join(", ");
                    
                    html += `
                        <tr>
                            <td><a href="#" class="page-link">${item.node}</a></td>
                            <td>${anomalyTypes}</td>
                            <td>${item.in_degree}</td>
                            <td>${item.out_degree}</td>
                            <td>${item.pagerank.toFixed(4)}</td>
                        </tr>
                    `;
                });
                
                html += "</tbody></table>";
                resultsDiv.html(html);
                
                // Add click handlers to page links
                resultsDiv.selectAll(".page-link").on("click", function(event) {
                    event.preventDefault();
                    const title = this.textContent;
                    loadPage(title);
                });
                
                // Highlight anomalous nodes in the graph
                const anomalousNodes = data.map(item => item.node);
                node.classed("highlight-yellow", d => anomalousNodes.includes(d.id));
            })
            .catch(error => {
                resultsDiv.html(`<p class="error">Error: ${error.message}</p>`);
            });
    });
}

// Setup link prediction
function setupLinkPrediction() {
    // Continuation of main.js file starting from where the previous file ended
    d3.select("#refreshPredictions").on("click", function() {
        const resultsDiv = d3.select("#predictionResults");
        resultsDiv.html("<p>Generating link predictions...</p>");
        
        fetch("/api/predict_links")
            .then(response => response.json())
            .then(data => {
                if (data.length === 0) {
                    resultsDiv.html("<p>Not enough data to make predictions. Explore more articles first.</p>");
                    return;
                }
                
                // Create table for predictions
                let html = `
                    <table>
                        <thead>
                            <tr>
                                <th>From</th>
                                <th>To</th>
                                <th>Common Connections</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                data.forEach(item => {
                    html += `
                        <tr>
                            <td><a href="#" class="page-link">${item.source}</a></td>
                            <td><a href="#" class="page-link">${item.target}</a></td>
                            <td>${item.common_neighbors}</td>
                            <td><button class="verify-link" data-source="${item.source}" data-target="${item.target}">Verify</button></td>
                        </tr>
                    `;
                });
                
                html += "</tbody></table>";
                resultsDiv.html(html);
                
                // Add click handlers to page links
                resultsDiv.selectAll(".page-link").on("click", function(event) {
                    event.preventDefault();
                    const title = this.textContent;
                    loadPage(title);
                });
                
                // Add click handlers to verify buttons
                resultsDiv.selectAll(".verify-link").on("click", function() {
                    const source = d3.select(this).attr("data-source");
                    const target = d3.select(this).attr("data-target");
                    loadPage(source);
                    
                    // Highlight target in case it appears in the resulting page
                    setTimeout(() => {
                        const iframe = wikiContent.select("iframe").node();
                        if (iframe) {
                            const doc = iframe.contentDocument || iframe.contentWindow.document;
                            const links = doc.querySelectorAll('a');
                            links.forEach(link => {
                                if (link.href.includes(target.replace(/ /g, '_'))) {
                                    link.style.backgroundColor = "yellow";
                                    link.scrollIntoView({ behavior: "smooth", block: "center" });
                                }
                            });
                        }
                    }, 2000); // Wait for page to load
                });
            })
            .catch(error => {
                resultsDiv.html(`<p class="error">Error: ${error.message}</p>`);
            });
    });
}

// Check URL parameters and initialize the app
function initApp() {
    // Setup all components
    setupSearch();
    setupNavigation();
    setupResizing();
    setupTabs();
    setupCentralityAnalysis();
    setupPathAnalysis();
    setupCommunityDetection();
    setupAnomalyDetection();
    setupLinkPrediction();
    
    // Check URL parameters for initial page to load
    const urlParams = new URLSearchParams(window.location.search);
    const initialPage = urlParams.get("page");
    
    if (initialPage) {
        loadPage(decodeURIComponent(initialPage));
    }
}

// Start the application
document.addEventListener("DOMContentLoaded", initApp);